a = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n']
b = ['o','p','q','r','s','t']

print(dir(a))
a.append(b)
ints=10
print(a[:ints])
print(a)